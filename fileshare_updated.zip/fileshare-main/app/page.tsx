"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { BlobFile, FolderEntry } from "@/lib/types";
import {
  fmtSize,
  fmtDate,
  iconFor,
  nameFromPathname,
  isImage,
  isTextFile,
  safeDecode,
} from "@/lib/utils";
import { APP_VERSION } from "@/lib/version";
import styles from "./page.module.css";

const MAX_BYTES = 50 * 1024 * 1024; // 50 MB
const THUMB_MAX_BYTES = 8 * 1024 * 1024; // only show inline thumbnails for images under 8 MB
const UPLOAD_CONCURRENCY = 3;

type UploadItem = { file: File; path: string };

const JUNK_NAMES = new Set([".ds_store", "thumbs.db", "desktop.ini", ".keep"]);
function isJunk(path: string): boolean {
  const n = (path.split("/").pop() || "").toLowerCase();
  return JUNK_NAMES.has(n);
}

// ── URL hash <-> folder prefix ("#/photos/2024" <-> "photos/2024/") ──
function prefixFromHash(): string {
  const h = window.location.hash.replace(/^#\/?/, "");
  if (!h) return "";
  try {
    const parts = h.split("/").map(decodeURIComponent).filter(Boolean);
    if (parts.some((p) => p === "." || p === "..")) return "";
    return parts.length ? parts.join("/") + "/" : "";
  } catch {
    return "";
  }
}

function hashFromPrefix(prefix: string): string {
  if (!prefix) return "#/";
  return "#/" + prefix.split("/").filter(Boolean).map(encodeURIComponent).join("/");
}

// ── Drag-and-drop folder traversal ──
function readAllEntries(reader: FileSystemDirectoryReader): Promise<FileSystemEntry[]> {
  return new Promise((resolve, reject) => {
    const all: FileSystemEntry[] = [];
    const readBatch = () =>
      reader.readEntries((batch) => {
        if (!batch.length) return resolve(all);
        all.push(...batch);
        readBatch(); // readEntries returns results in chunks — keep going until empty
      }, reject);
    readBatch();
  });
}

async function walkEntry(entry: FileSystemEntry, out: UploadItem[]): Promise<void> {
  if (entry.isFile) {
    const file = await new Promise<File>((res, rej) =>
      (entry as FileSystemFileEntry).file(res, rej)
    );
    out.push({ file, path: entry.fullPath.replace(/^\//, "") });
  } else if (entry.isDirectory) {
    const children = await readAllEntries((entry as FileSystemDirectoryEntry).createReader());
    for (const child of children) await walkEntry(child, out);
  }
}

function FolderIcon() {
  return (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"
        fill="var(--accent)"
        opacity="0.85"
      />
    </svg>
  );
}

export default function Home() {
  const [prefix, setPrefix] = useState<string | null>(null); // null until the URL hash is read
  const [files, setFiles] = useState<BlobFile[]>([]);
  const [folders, setFolders] = useState<FolderEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadLabel, setUploadLabel] = useState("");
  const [dragging, setDragging] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: "ok" | "err" } | null>(null);
  const [adminSecret, setAdminSecret] = useState("");
  const [secretInput, setSecretInput] = useState("");
  const [showSecretForm, setShowSecretForm] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [deletingUrl, setDeletingUrl] = useState<string | null>(null);

  const [showPastePanel, setShowPastePanel] = useState(false);
  const [pasteCode, setPasteCode] = useState("");
  const [pasteFilename, setPasteFilename] = useState("");
  const [pasteUploading, setPasteUploading] = useState(false);
  const [viewFile, setViewFile] = useState<{ name: string; content: string } | null>(null);

  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [creatingFolder, setCreatingFolder] = useState(false);
  const [viewImageUrl, setViewImageUrl] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prefixRef = useRef("");
  const reqId = useRef(0);
  const touchX = useRef<number | null>(null);

  prefixRef.current = prefix ?? "";

  async function verifySecret(secret: string): Promise<{ ok: boolean; error?: string }> {
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "x-admin-secret": secret },
      });
      const data = await res.json().catch(() => ({}));
      // Only accept an explicit {ok:true} from the server — never trust status alone
      if (res.ok && data.ok === true) return { ok: true };
      return { ok: false, error: data.error || "Wrong password" };
    } catch {
      return { ok: false, error: "Could not reach server" };
    }
  }

  // Restore admin session from localStorage — but re-verify with the server
  useEffect(() => {
    const stored = localStorage.getItem("fs_admin_secret");
    if (!stored) return;
    verifySecret(stored).then((r) => {
      if (r.ok) {
        setAdminSecret(stored);
        setIsAdmin(true);
      } else {
        localStorage.removeItem("fs_admin_secret");
      }
    });
  }, []);

  // The folder picker needs non-standard attributes React doesn't type
  useEffect(() => {
    const el = folderInputRef.current;
    if (!el) return;
    el.setAttribute("webkitdirectory", "");
    el.setAttribute("directory", "");
  }, []);

  // Keep the current folder in sync with the URL hash (so refresh + back button work)
  useEffect(() => {
    const sync = () => setPrefix(prefixFromHash());
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  function navigate(p: string) {
    window.location.hash = hashFromPrefix(p);
  }

  function showToast(msg: string, type: "ok" | "err" = "ok") {
    setToast({ msg, type });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 4000);
  }

  const fetchFiles = useCallback(async (p: string) => {
    const id = ++reqId.current;
    try {
      const res = await fetch(`/api/files?prefix=${encodeURIComponent(p)}`, {
        cache: "no-store",
      });
      const data = await res.json();
      if (id !== reqId.current) return; // a newer request superseded this one
      if (!res.ok) {
        showToast(data.error || "Failed to load files", "err");
        setFiles([]);
        setFolders([]);
        return;
      }
      setFiles(data.files || []);
      setFolders(data.folders || []);
    } catch {
      if (id === reqId.current) showToast("Failed to load files", "err");
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (prefix === null) return;
    setLoading(true);
    setShowNewFolder(false);
    setViewImageUrl(null);
    fetchFiles(prefix);
  }, [prefix, fetchFiles]);

  async function handleSecretSubmit(e: React.FormEvent) {
    e.preventDefault();
    const val = secretInput.trim();
    if (!val) return;
    const result = await verifySecret(val);
    if (!result.ok) {
      showToast(result.error || "Invalid secret", "err");
      return;
    }
    localStorage.setItem("fs_admin_secret", val);
    setAdminSecret(val);
    setIsAdmin(true);
    setShowSecretForm(false);
    setSecretInput("");
    showToast("Admin mode enabled");
  }

  function handleLogout() {
    localStorage.removeItem("fs_admin_secret");
    setAdminSecret("");
    setIsAdmin(false);
    showToast("Logged out");
  }

  // Uploads one file/blob to a full path like "photos/2024/a.png"
  async function uploadOne(
    path: string,
    body: Blob,
    type: string
  ): Promise<{ ok: boolean; error?: string }> {
    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: {
          "x-filename": encodeURIComponent(path),
          "x-admin-secret": adminSecret,
          "content-type": type || "application/octet-stream",
          "content-length": String(body.size),
        },
        body,
        // @ts-expect-error — duplex needed for streaming body in some envs
        duplex: "half",
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, error: data.error || "Upload failed" };
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error" };
    }
  }

  // Uploads files (optionally with relative folder paths) into the folder you're viewing
  async function uploadItems(items: UploadItem[]) {
    const target = prefixRef.current;

    const candidates = items.filter((i) => !isJunk(i.path));
    const toUpload: UploadItem[] = [];
    let tooBig = 0;
    let empty = 0;
    for (const it of candidates) {
      if (it.file.size > MAX_BYTES) tooBig++;
      else if (it.file.size === 0) empty++;
      else toUpload.push(it);
    }
    if (tooBig) showToast(`${tooBig} file${tooBig > 1 ? "s" : ""} over the 50 MB limit skipped`, "err");
    else if (empty && !toUpload.length) showToast("Empty files can't be uploaded", "err");
    if (!toUpload.length) return;

    setUploading(true);
    setUploadProgress(0);
    const total = toUpload.length;
    const labelFor = (done: number) =>
      total === 1 ? `Uploading ${toUpload[0].path}…` : `Uploading ${done}/${total} files…`;
    setUploadLabel(labelFor(0));

    let done = 0;
    let failed = 0;
    let firstError = "";
    let next = 0;

    async function worker() {
      while (next < toUpload.length) {
        const { file, path } = toUpload[next++];
        const r = await uploadOne(target + path, file, file.type);
        if (!r.ok) {
          failed++;
          if (!firstError) firstError = r.error || "Upload failed";
        }
        done++;
        setUploadProgress(Math.round((done / total) * 100));
        setUploadLabel(labelFor(done));
      }
    }
    await Promise.all(
      Array.from({ length: Math.min(UPLOAD_CONCURRENCY, total) }, () => worker())
    );

    const ok = total - failed;
    if (failed) {
      showToast(
        ok ? `${ok} uploaded, ${failed} failed — ${firstError}` : firstError,
        "err"
      );
    } else if (total === 1) {
      showToast(`${toUpload[0].file.name} uploaded ✓`);
    } else {
      showToast(`${ok} files uploaded ✓`);
    }

    setUploadProgress(100);
    setTimeout(() => {
      setUploading(false);
      setUploadProgress(0);
    }, 600);

    fetchFiles(prefixRef.current);
  }

  function itemsFromFileList(list: FileList): UploadItem[] {
    // webkitRelativePath is "myfolder/sub/a.png" for folder picks, "" for plain files
    return Array.from(list).map((f) => ({ file: f, path: f.webkitRelativePath || f.name }));
  }

  function onPickFiles(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files?.length) uploadItems(itemsFromFileList(e.target.files));
    e.target.value = ""; // allow picking the same thing again
  }

  async function deleteFile(url: string, name: string) {
    if (!confirm(`Delete "${name}"?`)) return;
    setDeletingUrl(url);
    try {
      const res = await fetch("/api/delete", {
        method: "DELETE",
        headers: {
          "content-type": "application/json",
          "x-admin-secret": adminSecret,
        },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Delete failed", "err");
      } else {
        showToast(`${name} deleted`);
        setFiles((prev) => prev.filter((f) => f.url !== url));
      }
    } catch {
      showToast("Delete failed", "err");
    } finally {
      setDeletingUrl(null);
    }
  }

  async function deleteFolder(folder: FolderEntry) {
    if (!confirm(`Delete the folder "${folder.name}" and everything inside it?`)) return;
    setDeletingUrl(folder.prefix);
    try {
      const res = await fetch("/api/delete", {
        method: "DELETE",
        headers: {
          "content-type": "application/json",
          "x-admin-secret": adminSecret,
        },
        body: JSON.stringify({ prefix: folder.prefix }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "Delete failed", "err");
      } else {
        showToast(`${folder.name} deleted`);
        setFolders((prev) => prev.filter((f) => f.prefix !== folder.prefix));
      }
    } catch {
      showToast("Delete failed", "err");
    } finally {
      setDeletingUrl(null);
    }
  }

  async function handleCreateFolder(e: React.FormEvent) {
    e.preventDefault();
    const name = newFolderName.trim();
    if (!name) return;
    setCreatingFolder(true);
    try {
      const res = await fetch("/api/folder", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-admin-secret": adminSecret,
        },
        body: JSON.stringify({ path: prefixRef.current + name }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        showToast(data.error || "Could not create folder", "err");
      } else {
        showToast(`Folder "${name}" created ✓`);
        setNewFolderName("");
        setShowNewFolder(false);
        fetchFiles(prefixRef.current);
      }
    } catch {
      showToast("Could not create folder", "err");
    } finally {
      setCreatingFolder(false);
    }
  }

  async function handlePasteUpload() {
    if (!pasteCode.trim()) {
      showToast("Nothing to upload — paste some code first", "err");
      return;
    }
    const rawName = pasteFilename.trim() || "snippet";
    const filename = rawName.endsWith(".txt") ? rawName : `${rawName}.txt`;
    const blob = new Blob([pasteCode], { type: "text/plain" });

    setPasteUploading(true);
    const r = await uploadOne(prefixRef.current + filename, blob, "text/plain");
    if (!r.ok) {
      showToast(r.error || "Upload failed", "err");
    } else {
      showToast(`${filename} created ✓`);
      setPasteCode("");
      setPasteFilename("");
      setShowPastePanel(false);
      fetchFiles(prefixRef.current);
    }
    setPasteUploading(false);
  }

  async function handleViewFile(file: { url: string; pathname: string }) {
    const name = nameFromPathname(safeDecode(file.pathname));
    try {
      const res = await fetch(file.url);
      const text = await res.text();
      setViewFile({ name, content: text });
    } catch {
      showToast("Could not load file content", "err");
    }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragging(false);
    const dt = e.dataTransfer;

    // Entries must be grabbed synchronously — the browser invalidates them after this handler returns
    const entries: FileSystemEntry[] = [];
    for (const item of Array.from(dt.items || [])) {
      if (item.kind !== "file") continue;
      const entry = item.webkitGetAsEntry?.();
      if (entry) entries.push(entry);
    }
    const fallback = Array.from(dt.files);

    (async () => {
      try {
        let items: UploadItem[] = [];
        if (entries.length) {
          for (const en of entries) await walkEntry(en, items);
        } else {
          items = fallback.map((f) => ({ file: f, path: f.name }));
        }
        uploadItems(items);
      } catch {
        showToast("Could not read the dropped folder", "err");
      }
    })();
  }

  // ── Derived data ──
  const entries = useMemo(
    () =>
      files.map((f) => {
        const name = nameFromPathname(safeDecode(f.pathname));
        return { ...f, name, image: isImage(name), text: isTextFile(name) };
      }),
    [files]
  );
  const imageList = useMemo(() => entries.filter((e) => e.image), [entries]);
  const imageIdx = viewImageUrl ? imageList.findIndex((i) => i.url === viewImageUrl) : -1;
  const currentImage = imageIdx >= 0 ? imageList[imageIdx] : null;

  const crumbs = useMemo(() => {
    const parts = (prefix || "").split("/").filter(Boolean);
    return parts.map((name, i) => ({
      name,
      prefix: parts.slice(0, i + 1).join("/") + "/",
    }));
  }, [prefix]);

  const stepImage = useCallback(
    (dir: 1 | -1) => {
      if (imageList.length < 2 || imageIdx < 0) return;
      const n = (imageIdx + dir + imageList.length) % imageList.length;
      setViewImageUrl(imageList[n].url);
    },
    [imageList, imageIdx]
  );

  // Keyboard: ← → to flip through images, Esc to close any viewer
  useEffect(() => {
    if (!viewImageUrl && !viewFile) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setViewImageUrl(null);
        setViewFile(null);
      } else if (viewImageUrl && e.key === "ArrowLeft") stepImage(-1);
      else if (viewImageUrl && e.key === "ArrowRight") stepImage(1);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [viewImageUrl, viewFile, stepImage]);

  const currentFolderName = crumbs.length ? crumbs[crumbs.length - 1].name : "Files";

  return (
    <>
      {/* Safe area top bar */}
      <div className={styles.safeTop} />

      <header className={styles.header}>
        <div className={styles.headerInner}>
          <div className={styles.logo}>
            File<span>Share</span>
          </div>
          <div className={styles.headerRight}>
            {isAdmin ? (
              <button className={`${styles.btn} ${styles.sm}`} onClick={handleLogout}>
                Sign out
              </button>
            ) : (
              <button
                className={`${styles.btn} ${styles.sm}`}
                onClick={() => setShowSecretForm((v) => !v)}
              >
                Admin
              </button>
            )}
          </div>
        </div>
      </header>

      <main className={styles.main}>

        {/* Admin secret form */}
        {showSecretForm && !isAdmin && (
          <form className={styles.secretForm} onSubmit={handleSecretSubmit}>
            <input
              className={styles.secretInput}
              type="password"
              placeholder="Enter admin secret…"
              value={secretInput}
              onChange={(e) => setSecretInput(e.target.value)}
              autoFocus
            />
            <button className={`${styles.btn} ${styles.primary}`} type="submit">
              Unlock
            </button>
          </form>
        )}

        {/* Breadcrumbs */}
        <nav className={styles.crumbs} aria-label="Folder path">
          <button
            className={`${styles.crumb} ${!crumbs.length ? styles.crumbCurrent : ""}`}
            onClick={() => crumbs.length && navigate("")}
          >
            Home
          </button>
          {crumbs.map((c, i) => (
            <span key={c.prefix} className={styles.crumbWrap}>
              <span className={styles.crumbSep}>/</span>
              <button
                className={`${styles.crumb} ${i === crumbs.length - 1 ? styles.crumbCurrent : ""}`}
                onClick={() => i < crumbs.length - 1 && navigate(c.prefix)}
              >
                {c.name}
              </button>
            </span>
          ))}
        </nav>

        {/* Upload zone — only shown to admin */}
        {isAdmin && (
          <div className={styles.uploadSection}>
            <div
              className={`${styles.dropZone} ${dragging ? styles.drag : ""} ${uploading ? styles.disabled : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              onClick={() => !uploading && fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className={styles.fileInput}
                onChange={onPickFiles}
              />
              <input
                ref={folderInputRef}
                type="file"
                multiple
                className={styles.fileInput}
                onChange={onPickFiles}
              />
              <div className={styles.uploadIcon}>📁</div>
              <p className={styles.uploadTitle}>
                {dragging ? "Drop to upload" : "Drop files or folders here, or tap to browse"}
              </p>
              <p className={styles.uploadSub}>
                Uploading to {prefix ? `/${prefix}` : "Home"} · Max 50 MB per file
              </p>
              <div className={styles.uploadBtns}>
                <span className={`${styles.btn} ${styles.primary} ${styles.noClick}`}>
                  Choose files
                </span>
                <button
                  type="button"
                  className={styles.btn}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!uploading) folderInputRef.current?.click();
                  }}
                >
                  📂 Upload folder
                </button>
              </div>
            </div>

            {uploading && (
              <div className={styles.progressCard}>
                <div className={styles.progressTop}>
                  <span className={styles.progressLabel}>{uploadLabel}</span>
                  <span className={styles.progressPct}>{uploadProgress}%</span>
                </div>
                <div className={styles.progressBar}>
                  <div
                    className={styles.progressFill}
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Admin tools: new folder + paste code */}
        {isAdmin && (
          <div className={styles.pasteSection}>
            <div className={styles.toolbar}>
              <button
                className={`${styles.btn} ${showNewFolder ? styles.primary : ""}`}
                onClick={() => setShowNewFolder((v) => !v)}
              >
                ➕ {showNewFolder ? "Cancel" : "New folder"}
              </button>
              <button
                className={`${styles.btn} ${showPastePanel ? styles.primary : ""}`}
                onClick={() => setShowPastePanel((v) => !v)}
              >
                📋 {showPastePanel ? "Close" : "Paste Code"}
              </button>
            </div>

            {showNewFolder && (
              <form className={`${styles.secretForm} ${styles.folderForm}`} onSubmit={handleCreateFolder}>
                <input
                  className={styles.secretInput}
                  type="text"
                  placeholder={`Folder name${prefix ? ` (inside ${currentFolderName})` : ""}…`}
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  autoFocus
                />
                <button
                  className={`${styles.btn} ${styles.primary}`}
                  type="submit"
                  disabled={creatingFolder || !newFolderName.trim()}
                >
                  {creatingFolder ? "Creating…" : "Create"}
                </button>
              </form>
            )}

            {showPastePanel && (
              <div className={styles.pasteCard}>
                <p className={styles.pasteLabel}>Paste your code or text below — it will be saved as a .txt file.</p>
                <input
                  className={styles.pasteInput}
                  type="text"
                  placeholder="Filename (e.g. my-script) — defaults to snippet.txt"
                  value={pasteFilename}
                  onChange={(e) => setPasteFilename(e.target.value)}
                />
                <textarea
                  className={styles.pasteTextarea}
                  placeholder="Paste code here…"
                  value={pasteCode}
                  onChange={(e) => setPasteCode(e.target.value)}
                  spellCheck={false}
                />
                <div className={styles.pasteActions}>
                  <span className={styles.pasteChars}>{pasteCode.length} chars</span>
                  <button
                    className={`${styles.btn} ${styles.primary}`}
                    onClick={handlePasteUpload}
                    disabled={pasteUploading || !pasteCode.trim()}
                  >
                    {pasteUploading ? "Saving…" : "Save as .txt ↑"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* File list */}
        <div className={styles.sectionHead}>
          <p className={styles.sectionTitle}>{currentFolderName}</p>
          <span className={styles.badge}>
            {folders.length > 0 &&
              `${folders.length} ${folders.length === 1 ? "folder" : "folders"} · `}
            {files.length} {files.length === 1 ? "file" : "files"}
          </span>
        </div>

        {loading ? (
          <div className={styles.emptyState}>
            <div className={styles.spinner} />
          </div>
        ) : files.length === 0 && folders.length === 0 ? (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>📂</div>
            <p className={styles.emptyText}>
              {prefix ? "This folder is empty" : "No files uploaded yet"}
            </p>
          </div>
        ) : (
          <div className={styles.fileList}>
            {/* Folders first */}
            {folders.map((folder) => {
              const isDeleting = deletingUrl === folder.prefix;
              return (
                <div
                  key={folder.prefix}
                  className={`${styles.fileCard} ${styles.folderCard} ${isDeleting ? styles.deleting : ""}`}
                  onClick={() => navigate(folder.prefix)}
                  role="link"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === "Enter" && navigate(folder.prefix)}
                >
                  <div className={styles.fileIcon}>
                    <FolderIcon />
                  </div>
                  <div className={styles.fileInfo}>
                    <p className={styles.fileName} title={folder.name}>{folder.name}</p>
                    <p className={styles.fileMeta}>Folder</p>
                  </div>
                  <div className={styles.fileActions}>
                    {isAdmin && (
                      <button
                        className={`${styles.btn} ${styles.sm} ${styles.danger}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteFolder(folder);
                        }}
                        disabled={isDeleting}
                        aria-label={`Delete folder ${folder.name}`}
                      >
                        {isDeleting ? "…" : "✕"}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {entries.map((file) => {
              const { name } = file;
              const isDeleting = deletingUrl === file.url;
              const showThumb = file.image && file.size <= THUMB_MAX_BYTES;
              return (
                <div key={file.url} className={`${styles.fileCard} ${isDeleting ? styles.deleting : ""}`}>
                  <div
                    className={`${styles.fileIcon} ${file.image ? styles.clickable : ""}`}
                    onClick={() => file.image && setViewImageUrl(file.url)}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      className={showThumb ? styles.thumb : undefined}
                      src={showThumb ? file.url : iconFor(name)}
                      alt=""
                      width={44}
                      height={44}
                      draggable={false}
                      loading="lazy"
                      decoding="async"
                      onError={(e) => {
                        const img = e.currentTarget;
                        img.onerror = null;
                        img.classList.remove(styles.thumb);
                        img.src = iconFor(name);
                      }}
                    />
                  </div>
                  <div className={styles.fileInfo}>
                    <p className={styles.fileName} title={name}>{name}</p>
                    <p className={styles.fileMeta}>
                      {fmtSize(file.size)} · {fmtDate(file.uploadedAt)}
                    </p>
                  </div>
                  <div className={styles.fileActions}>
                    {file.image && (
                      <button
                        className={`${styles.btn} ${styles.sm}`}
                        onClick={() => setViewImageUrl(file.url)}
                        aria-label={`View ${name}`}
                      >
                        🖼 View
                      </button>
                    )}
                    {file.text && (
                      <button
                        className={`${styles.btn} ${styles.sm}`}
                        onClick={() => handleViewFile(file)}
                        aria-label={`View ${name}`}
                      >
                        👁 View
                      </button>
                    )}
                    <a
                      className={`${styles.btn} ${styles.sm}`}
                      href={file.downloadUrl}
                      download={name}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Download ${name}`}
                    >
                      ↓ Download
                    </a>
                    {isAdmin && (
                      <button
                        className={`${styles.btn} ${styles.sm} ${styles.danger}`}
                        onClick={() => deleteFile(file.url, name)}
                        disabled={isDeleting}
                        aria-label={`Delete ${name}`}
                      >
                        {isDeleting ? "…" : "✕"}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      <p style={{ textAlign: "center", fontSize: 11, opacity: 0.4, padding: "16px 0 32px" }}>
        {APP_VERSION}
      </p>

      {/* Toast */}
      {toast && (
        <div className={`${styles.toast} ${toast.type === "err" ? styles.toastErr : styles.toastOk}`}>
          {toast.msg}
        </div>
      )}

      {/* Image viewer */}
      {currentImage && (
        <div
          className={styles.imgOverlay}
          onClick={() => setViewImageUrl(null)}
          onTouchStart={(e) => { touchX.current = e.touches[0].clientX; }}
          onTouchEnd={(e) => {
            if (touchX.current === null) return;
            const dx = e.changedTouches[0].clientX - touchX.current;
            touchX.current = null;
            if (Math.abs(dx) > 60) stepImage(dx > 0 ? -1 : 1);
          }}
        >
          <div className={styles.imgTopBar} onClick={(e) => e.stopPropagation()}>
            <span className={styles.imgTitle}>{currentImage.name}</span>
            {imageList.length > 1 && (
              <span className={styles.imgCount}>{imageIdx + 1} / {imageList.length}</span>
            )}
            <a
              className={`${styles.btn} ${styles.sm}`}
              href={currentImage.downloadUrl}
              download={currentImage.name}
              target="_blank"
              rel="noopener noreferrer"
            >
              ↓
            </a>
            <button className={`${styles.btn} ${styles.sm}`} onClick={() => setViewImageUrl(null)}>
              ✕ Close
            </button>
          </div>
          {imageList.length > 1 && (
            <button
              className={`${styles.imgNav} ${styles.imgPrev}`}
              onClick={(e) => { e.stopPropagation(); stepImage(-1); }}
              aria-label="Previous image"
            >
              ‹
            </button>
          )}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            key={currentImage.url}
            className={styles.imgFull}
            src={currentImage.url}
            alt={currentImage.name}
            draggable={false}
            onClick={(e) => e.stopPropagation()}
          />
          {imageList.length > 1 && (
            <button
              className={`${styles.imgNav} ${styles.imgNext}`}
              onClick={(e) => { e.stopPropagation(); stepImage(1); }}
              aria-label="Next image"
            >
              ›
            </button>
          )}
        </div>
      )}

      {/* File viewer modal */}
      {viewFile && (
        <div className={styles.modalOverlay} onClick={() => setViewFile(null)}>
          <div className={styles.modalBox} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <span className={styles.modalTitle}>{viewFile.name}</span>
              <button className={`${styles.btn} ${styles.sm}`} onClick={() => setViewFile(null)}>✕ Close</button>
            </div>
            <pre className={styles.modalContent}>{viewFile.content}</pre>
          </div>
        </div>
      )}
    </>
  );
}
