
import { del, list } from "@vercel/blob";
import { NextRequest, NextResponse } from "next/server";
import { checkAdmin } from "@/lib/auth";
import { cleanPrefix } from "@/lib/paths";

export const runtime = "edge";

export async function DELETE(req: NextRequest) {
  // Auth check
  const auth = checkAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  const body = await req.json().catch(() => ({}));
  const { url, prefix } = body as { url?: unknown; prefix?: unknown };

  // Delete a whole folder (everything under the prefix)
  if (typeof prefix === "string") {
    const clean = cleanPrefix(prefix);
    if (!clean) {
      // "" (the root) is refused on purpose so this can never wipe everything
      return NextResponse.json({ error: "Invalid folder" }, { status: 400 });
    }
    try {
      const urls: string[] = [];
      let cursor: string | undefined;
      do {
        const page = await list({ prefix: clean, cursor, limit: 1000 });
        urls.push(...page.blobs.map((b) => b.url));
        cursor = page.hasMore ? page.cursor : undefined;
      } while (cursor);
      for (let i = 0; i < urls.length; i += 100) {
        await del(urls.slice(i, i + 100));
      }
      return NextResponse.json({ success: true, deleted: urls.length });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Delete failed";
      console.error("Folder delete error:", err);
      return NextResponse.json({ error: message }, { status: 500 });
    }
  }

  if (!url || typeof url !== "string") {
    return NextResponse.json({ error: "Missing url" }, { status: 400 });
  }

  try {
    await del(url);
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Delete failed";
    console.error("Delete error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
