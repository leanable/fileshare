import { put } from "@vercel/blob";
import { NextRequest, NextResponse } from "next/server";
import { checkAdmin } from "@/lib/auth";
import { cleanPath, KEEP_FILE } from "@/lib/paths";

export const runtime = "edge";

// POST { path: "photos/2024" } → creates the folder.
// Blob storage has no empty folders, so we drop a tiny hidden ".keep" file in it.
export async function POST(req: NextRequest) {
  const auth = checkAdmin(req);
  if (!auth.ok) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  const body = await req.json().catch(() => ({}));
  const path = cleanPath(typeof body.path === "string" ? body.path : "");
  if (!path) {
    return NextResponse.json({ error: "Invalid folder name" }, { status: 400 });
  }

  try {
    await put(`${path}/${KEEP_FILE}`, "keep", {
      access: "public",
      addRandomSuffix: false,
      contentType: "text/plain",
    });
    return NextResponse.json({ success: true, path: path + "/" });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Could not create folder";
    // Folder already has its placeholder → that's fine
    if (/already exists/i.test(message)) {
      return NextResponse.json({ success: true, path: path + "/", existed: true });
    }
    console.error("Folder error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
