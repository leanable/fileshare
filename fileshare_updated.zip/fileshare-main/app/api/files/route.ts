import { list } from "@vercel/blob";
import { NextRequest, NextResponse } from "next/server";
import { cleanPrefix, KEEP_FILE } from "@/lib/paths";

export const runtime = "edge";
export const dynamic = "force-dynamic";

// GET /api/files?prefix=photos/2024/  → files + sub-folders directly inside that folder
export async function GET(req: NextRequest) {
  const prefix = cleanPrefix(req.nextUrl.searchParams.get("prefix"));
  if (prefix === null) {
    return NextResponse.json({ error: "Invalid folder path" }, { status: 400 });
  }

  try {
    const blobs: Awaited<ReturnType<typeof list>>["blobs"] = [];
    const folderSet = new Set<string>();
    let cursor: string | undefined;

    do {
      const page = await list({
        prefix: prefix || undefined,
        mode: "folded",
        cursor,
        limit: 1000,
      });
      blobs.push(...page.blobs);
      page.folders.forEach((f) => folderSet.add(f));
      cursor = page.hasMore ? page.cursor : undefined;
    } while (cursor);

    const files = blobs
      .filter((b) => b.pathname.split("/").pop() !== KEEP_FILE)
      .map((blob) => ({
        url: blob.url,
        downloadUrl: blob.downloadUrl,
        pathname: blob.pathname,
        size: blob.size,
        uploadedAt: blob.uploadedAt,
      }));

    // Newest first
    files.sort(
      (a, b) =>
        new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );

    const folders = Array.from(folderSet)
      .map((p) => ({
        prefix: p,
        name: p.split("/").filter(Boolean).pop() || p,
      }))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));

    return NextResponse.json({ files, folders, prefix });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to list files";
    console.error("List error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
