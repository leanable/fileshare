// Shared by the client and the API routes. Vercel Blob has no real folders:
// a "folder" is just a path prefix like "photos/2024/".

/** Placeholder object that lets an otherwise empty folder exist. Hidden from listings. */
export const KEEP_FILE = ".keep";

const MAX_PATH = 900; // Blob pathnames max out at 950 chars

function segmentsOf(input: string): string[] | null {
  if (typeof input !== "string") return null;
  const parts = input
    .replace(/\\/g, "/")
    .split("/")
    .map((s) => s.trim())
    .filter(Boolean);
  for (const p of parts) {
    if (p === "." || p === ".." || p === KEEP_FILE) return null;
    if (/[\u0000-\u001f\u007f]/.test(p)) return null;
  }
  return parts;
}

/** Cleans a relative file/folder path ("a/b/c.txt"). Returns null if empty or unsafe. */
export function cleanPath(input: string): string | null {
  const parts = segmentsOf(input);
  if (!parts || !parts.length) return null;
  const out = parts.join("/");
  return out.length > MAX_PATH ? null : out;
}

/** Cleans a folder prefix: "" for the root, otherwise "a/b/". Returns null if unsafe. */
export function cleanPrefix(input: string | null | undefined): string | null {
  if (!input) return "";
  const parts = segmentsOf(input);
  if (!parts) return null;
  if (!parts.length) return "";
  const out = parts.join("/");
  return out.length > MAX_PATH ? null : out + "/";
}
