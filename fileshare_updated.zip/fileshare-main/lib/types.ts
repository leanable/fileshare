export interface BlobFile {
  url: string;
  downloadUrl: string;
  pathname: string;
  size: number;
  uploadedAt: string;
}

export interface FolderEntry {
  name: string;
  /** Full prefix including trailing slash, e.g. "photos/2024/" */
  prefix: string;
}
