// Bump this when you deploy so you can tell which build is live.
export const APP_VERSION = "v4-2026-11-06";
